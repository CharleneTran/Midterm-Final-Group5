function NextUI(id){
    return`
    <div id="${id}" style="
    width: 50px;
    height: 30px;
    margin-right: 10px;
    font-weight: 700;
    ">
    NEXT>> 
    </div>
    `
}