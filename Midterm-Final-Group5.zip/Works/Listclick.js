function ListClicked1(){
    document.querySelector(".calories").style.display = "block"
    document.querySelector(".answer").style.display = "none"
    document.querySelector(".question").style.display = "none"
}

function ListClicked2(){
    document.querySelector(".question2").style.display = "none"
    document.querySelector(".effects").style.display = "block"
}

function ListClicked3(){
    document.querySelector("#second_info p").style.display = "block"
}

function ListClicked4(){
    document.querySelector("#third_info h2").style.display = "none"
    document.querySelector("#seventeenth-content").style.display = "block"
}