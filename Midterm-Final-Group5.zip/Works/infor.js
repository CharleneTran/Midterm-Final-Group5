function p1Clicked(){
    document.querySelector("#p1").style.display = "block"
    document.querySelector("#p2").style.display = "none"

}
function p2Clicked(){
    document.querySelector("#p1").style.display = "none"
    document.querySelector("#p2").style.display = "block"

}
function p3Clicked(){

    document.querySelector("#p3").style.display = "block"
    document.querySelector("#p4").style.display = "none"

}
function p4Clicked(){

    document.querySelector("#p3").style.display = "none"
    document.querySelector("#p4").style.display = "block"

}
function p5Clicked(){

    document.querySelector("#p5").style.display = "block"
    document.querySelector("#p6").style.display = "none"
}
function p6Clicked(){

    document.querySelector("#p5").style.display = "none"
    document.querySelector("#p6").style.display = "block"
}